"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Trophy,
  Star,
  Zap,
  Users,
  Award,
  Wallet,
  Menu,
  X,
  Home,
  UserPlus,
  Crown,
  Bell,
  Gift,
  Clock,
  CheckCircle,
  Shield,
  Hash,
  Calendar,
  BarChart3,
} from "lucide-react"

interface Creator {
  id: string
  name: string
  bio: string
  avatar: string
  recognitions: number
  isRecognizedThisWeek: boolean
  hasPendingBadge: boolean
  recognitionStatus: "waiting" | "recognized" | "claimed"
  lastRecognitionWeek?: string
  address?: string
  metadata?: string
  profilePicture?: string
  isActive: boolean
}

interface VIP {
  id: string
  name: string
  isConnected: boolean
  address?: string
  encryptedId?: string
  hasNominatedThisWeek: boolean
}

interface Recognition {
  id: string
  creatorId: string
  reason: string
  week: string
  timestamp: Date
  encryptedVIPId?: string
  encryptedReason?: string
  weekNumber: number
  creatorName: string
  tokenId?: number
}

export default function ZamaRecognitionSystem() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [isVIP, setIsVIP] = useState(false)
  const [isCreator, setIsCreator] = useState(false)
  const [isWalletConnected, setIsWalletConnected] = useState(false)
  const [selectedCreator, setSelectedCreator] = useState<Creator | null>(null)
  const [recognitionReason, setRecognitionReason] = useState("")
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [notifications, setNotifications] = useState<string[]>([])
  const [showNotification, setShowNotification] = useState(false)
  const [currentWeek, setCurrentWeek] = useState<number>(0)
  const [walletAddress, setWalletAddress] = useState<string>("")

  const [creatorForm, setCreatorForm] = useState({
    name: "",
    bio: "",
    avatar: "",
    metadata: "",
  })

  const [currentCreatorProfile, setCurrentCreatorProfile] = useState<Creator | null>(null)
  const [currentVIPProfile, setCurrentVIPProfile] = useState<VIP | null>(null)

  const [creators, setCreators] = useState<Creator[]>([
    {
      id: "1",
      name: "CryptoJohn",
      bio: "I create educational crypto content and DeFi tutorials",
      avatar: "/crypto-educator.png",
      recognitions: 3,
      isRecognizedThisWeek: false,
      hasPendingBadge: false,
      recognitionStatus: "waiting",
      isActive: true,
      address: "0x1234...5678",
      metadata: "Educational content creator specializing in DeFi",
    },
    {
      id: "2",
      name: "BlockchainBob",
      bio: "NFT artist and Web3 developer building the future",
      avatar: "/nft-artist.jpg",
      recognitions: 7,
      isRecognizedThisWeek: true,
      hasPendingBadge: true,
      recognitionStatus: "recognized",
      lastRecognitionWeek: new Date().toISOString().slice(0, 10),
      isActive: true,
      address: "0x2345...6789",
      metadata: "NFT artist and Web3 developer",
    },
    {
      id: "3",
      name: "DeFiAlice",
      bio: "Smart contract auditor and security researcher",
      avatar: "/security-researcher.jpg",
      recognitions: 12,
      isRecognizedThisWeek: false,
      hasPendingBadge: false,
      recognitionStatus: "waiting",
      isActive: true,
      address: "0x3456...7890",
      metadata: "Smart contract security specialist",
    },
  ])

  const [recognitions, setRecognitions] = useState<Recognition[]>([])

  useEffect(() => {
    const weekNumber = Math.floor(Date.now() / (1000 * 60 * 60 * 24 * 7))
    setCurrentWeek(weekNumber)
  }, [])

  useEffect(() => {
    if (isCreator && currentCreatorProfile?.isRecognizedThisWeek && currentCreatorProfile?.hasPendingBadge) {
      setNotifications((prev) => [...prev, `Congratulations! You've been recognized this week!`])
      setShowNotification(true)
      setTimeout(() => setShowNotification(false), 5000)
    }
  }, [currentCreatorProfile?.isRecognizedThisWeek, currentCreatorProfile?.hasPendingBadge, isCreator])

  const handleConnectWallet = () => {
    const mockAddress = `0x${Math.random().toString(16).substr(2, 8)}...${Math.random().toString(16).substr(2, 4)}`
    setWalletAddress(mockAddress)
    setIsWalletConnected(true)
  }

  const handleBecomeVIP = () => {
    if (!isWalletConnected) {
      setNotifications((prev) => [...prev, "Please connect your wallet first"])
      setShowNotification(true)
      setTimeout(() => setShowNotification(false), 3000)
      return
    }

    const vipProfile: VIP = {
      id: Date.now().toString(),
      name: `VIP_${walletAddress.slice(-4)}`,
      isConnected: true,
      address: walletAddress,
      encryptedId: `encrypted_${Math.random().toString(16).substr(2, 8)}`,
      hasNominatedThisWeek: false,
    }

    setCurrentVIPProfile(vipProfile)
    setIsVIP(true)
    setNotifications((prev) => [...prev, "VIP registration successful! Your identity is encrypted for privacy."])
    setShowNotification(true)
    setTimeout(() => setShowNotification(false), 5000)
  }

  const handleRegisterCreator = () => {
    if (!creatorForm.name || !creatorForm.bio) return
    if (!isWalletConnected) {
      setNotifications((prev) => [...prev, "Please connect your wallet first"])
      setShowNotification(true)
      setTimeout(() => setShowNotification(false), 3000)
      return
    }

    // Check if name is already taken
    const nameExists = creators.some((c) => c.name.toLowerCase() === creatorForm.name.toLowerCase())
    if (nameExists) {
      setNotifications((prev) => [...prev, "Creator name already taken. Please choose another."])
      setShowNotification(true)
      setTimeout(() => setShowNotification(false), 3000)
      return
    }

    const newCreator: Creator = {
      id: Date.now().toString(),
      name: creatorForm.name,
      bio: creatorForm.bio,
      avatar: creatorForm.avatar || "/creator-avatar.png",
      recognitions: 0,
      isRecognizedThisWeek: false,
      hasPendingBadge: false,
      recognitionStatus: "waiting",
      isActive: true,
      address: walletAddress,
      metadata: creatorForm.metadata || creatorForm.bio,
      profilePicture: creatorForm.avatar || "/creator-avatar.png",
    }

    setCreators((prev) => [...prev, newCreator])
    setCurrentCreatorProfile(newCreator)
    setIsCreator(true)
    setCreatorForm({ name: "", bio: "", avatar: "", metadata: "" })
    setActiveTab("dashboard")

    setNotifications((prev) => [...prev, `Creator profile registered successfully! Welcome, ${newCreator.name}!`])
    setShowNotification(true)
    setTimeout(() => setShowNotification(false), 5000)
  }

  const handleRecognizeCreator = (creator: Creator) => {
    if (!isVIP || !currentVIPProfile) {
      setNotifications((prev) => [...prev, "Only VIPs can give recognition"])
      setShowNotification(true)
      setTimeout(() => setShowNotification(false), 3000)
      return
    }

    if (currentVIPProfile.hasNominatedThisWeek) {
      setNotifications((prev) => [...prev, "You have already nominated someone this week"])
      setShowNotification(true)
      setTimeout(() => setShowNotification(false), 3000)
      return
    }

    if (creator.isRecognizedThisWeek) {
      setNotifications((prev) => [...prev, `${creator.name} has already been recognized this week`])
      setShowNotification(true)
      setTimeout(() => setShowNotification(false), 3000)
      return
    }

    const newRecognition: Recognition = {
      id: Date.now().toString(),
      creatorId: creator.id,
      reason: recognitionReason || "Great work this week!",
      week: new Date().toISOString().slice(0, 10),
      timestamp: new Date(),
      encryptedVIPId: currentVIPProfile.encryptedId,
      encryptedReason: btoa(recognitionReason || "Great work this week!"), // Simple base64 encoding for demo
      weekNumber: currentWeek,
      creatorName: creator.name,
    }

    setRecognitions((prev) => [...prev, newRecognition])
    setCreators((prev) =>
      prev.map((c) =>
        c.id === creator.id
          ? {
              ...c,
              recognitions: c.recognitions + 1,
              isRecognizedThisWeek: true,
              hasPendingBadge: true,
              recognitionStatus: "recognized",
              lastRecognitionWeek: new Date().toISOString().slice(0, 10),
            }
          : c,
      ),
    )

    // Update VIP nomination status
    setCurrentVIPProfile((prev) => (prev ? { ...prev, hasNominatedThisWeek: true } : null))

    if (currentCreatorProfile?.id === creator.id) {
      setCurrentCreatorProfile((prev) =>
        prev
          ? {
              ...prev,
              recognitions: prev.recognitions + 1,
              isRecognizedThisWeek: true,
              hasPendingBadge: true,
              recognitionStatus: "recognized",
              lastRecognitionWeek: new Date().toISOString().slice(0, 10),
            }
          : null,
      )
    }

    setSelectedCreator(null)
    setRecognitionReason("")

    setNotifications((prev) => [...prev, `Recognition sent to ${creator.name}! Your identity remains encrypted.`])
    setShowNotification(true)
    setTimeout(() => setShowNotification(false), 5000)
  }

  const handleMintBadge = (creatorId: string) => {
    const creator = creators.find((c) => c.id === creatorId)
    if (!creator) return

    const recognition = recognitions.find((r) => r.creatorId === creatorId && r.weekNumber === currentWeek)
    if (!recognition) return

    // Simulate NFT minting
    const tokenId = Math.floor(Math.random() * 10000) + 1
    const updatedRecognition = { ...recognition, tokenId }

    setRecognitions((prev) => prev.map((r) => (r.id === recognition.id ? updatedRecognition : r)))

    setCreators((prev) =>
      prev.map((c) =>
        c.id === creatorId
          ? {
              ...c,
              hasPendingBadge: false,
              recognitionStatus: "claimed",
            }
          : c,
      ),
    )

    if (currentCreatorProfile?.id === creatorId) {
      setCurrentCreatorProfile((prev) =>
        prev
          ? {
              ...prev,
              hasPendingBadge: false,
              recognitionStatus: "claimed",
            }
          : null,
      )
    }

    setNotifications((prev) => [
      ...prev,
      `🎉 Recognition NFT #${tokenId} minted successfully! Badge added to your wallet.`,
    ])
    setShowNotification(true)
    setTimeout(() => setShowNotification(false), 5000)
  }

  const navigationItems = [
    { id: "dashboard", label: "DASHBOARD", icon: Home },
    { id: "creators", label: "CREATORS", icon: Users },
    { id: "profile", label: "CREATOR PROFILE", icon: UserPlus },
    { id: "recognition", label: "MY RECOGNITION", icon: Award },
    { id: "vip", label: "BECOME VIP", icon: Crown },
  ]

  return (
    <div className="min-h-screen bg-background flex">
      {showNotification && notifications.length > 0 && (
        <div className="fixed top-4 right-4 z-50 bg-secondary text-secondary-foreground p-4 border border-border shadow-lg max-w-sm">
          <div className="flex items-center space-x-2">
            <Bell className="h-4 w-4" />
            <p className="font-gaming text-xs">{notifications[notifications.length - 1]}</p>
          </div>
        </div>
      )}

      {/* ... existing sidebar code ... */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-card border-r border-border transform transition-transform duration-300 ease-in-out ${isSidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 lg:static lg:inset-0`}
      >
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-2">
            <Zap className="h-6 w-6 text-primary" />
            <span className="font-gaming text-sm text-primary">ZAMA</span>
          </div>
          <Button variant="ghost" size="sm" className="lg:hidden" onClick={() => setIsSidebarOpen(false)}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <nav className="p-4 space-y-2">
          {[
            { id: "dashboard", label: "DASHBOARD", icon: Home },
            { id: "creators", label: "CREATORS", icon: Users },
            { id: "profile", label: "CREATOR PROFILE", icon: UserPlus },
            { id: "recognition", label: "MY RECOGNITION", icon: Award },
            { id: "vip", label: "BECOME VIP", icon: Crown },
          ].map((item) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id === "vip" ? "dashboard" : item.id)
                  if (item.id === "vip") handleBecomeVIP()
                  setIsSidebarOpen(false)
                }}
                className={`w-full flex items-center space-x-3 px-3 py-2 text-left font-gaming text-xs transition-colors duration-200 ${
                  activeTab === item.id
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{item.label}</span>
              </button>
            )
          })}
        </nav>
      </div>

      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={() => setIsSidebarOpen(false)} />
      )}

      <div className="flex-1 flex flex-col min-h-screen lg:ml-0">
        <header className="border-b border-border bg-card">
          <div className="px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button variant="ghost" size="sm" className="lg:hidden" onClick={() => setIsSidebarOpen(true)}>
                  <Menu className="h-4 w-4" />
                </Button>
                <div className="flex items-center space-x-2">
                  <Zap className="h-8 w-8 text-primary" />
                  <h1 className="font-gaming text-xl text-primary">ZAMA RECOGNITION</h1>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Badge variant="outline" className="font-gaming text-xs">
                  <Calendar className="mr-1 h-3 w-3" />
                  WEEK {currentWeek}
                </Badge>
                {isVIP && (
                  <Badge variant="secondary" className="font-gaming text-xs">
                    <Crown className="mr-1 h-3 w-3" />
                    VIP
                    {currentVIPProfile?.encryptedId && <Shield className="ml-1 h-3 w-3" title="Identity Encrypted" />}
                  </Badge>
                )}
                {isCreator && (
                  <Badge variant="outline" className="font-gaming text-xs">
                    <UserPlus className="mr-1 h-3 w-3" />
                    CREATOR
                  </Badge>
                )}
                {!isWalletConnected ? (
                  <Button
                    onClick={handleConnectWallet}
                    className="bg-primary text-primary-foreground hover:bg-primary/90 font-gaming text-sm"
                  >
                    <Wallet className="mr-2 h-4 w-4" />
                    CONNECT WALLET
                  </Button>
                ) : (
                  <Badge variant="secondary" className="font-gaming text-xs">
                    <Wallet className="mr-1 h-3 w-3" />
                    {walletAddress}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 px-4 py-8">
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              <div className="text-center space-y-4">
                <h2 className="font-gaming text-3xl text-primary">DIGITAL RECOGNITION SYSTEM</h2>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Like a digital "Employee of the Month" program for creators, with privacy features built in using
                  encrypted VIP identities.
                </p>
              </div>

              {isCreator && currentCreatorProfile?.hasPendingBadge && (
                <Card className="bg-secondary/10 border-secondary animate-pulse">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Bell className="h-5 w-5 text-secondary animate-bounce" />
                        <div>
                          <p className="font-gaming text-sm text-secondary">🎉 RECOGNITION RECEIVED!</p>
                          <p className="text-xs text-muted-foreground">
                            You have a recognition NFT badge to claim - Week {currentWeek}
                          </p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Shield className="h-3 w-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">VIP identity encrypted for privacy</span>
                          </div>
                        </div>
                      </div>
                      <Button
                        onClick={() => handleMintBadge(currentCreatorProfile.id)}
                        className="bg-secondary text-secondary-foreground hover:bg-secondary/90 font-gaming text-xs"
                      >
                        <Gift className="mr-1 h-3 w-3" />
                        MINT NFT BADGE
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* ... existing recognition status card ... */}
              {isCreator && currentCreatorProfile && (
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-gaming text-primary flex items-center">
                      <Clock className="mr-2 h-5 w-5" />
                      YOUR RECOGNITION STATUS
                    </CardTitle>
                    <CardDescription>Track your weekly recognition progress and NFT badges</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        {currentCreatorProfile.recognitionStatus === "waiting" && (
                          <>
                            <Clock className="h-8 w-8 text-muted-foreground" />
                            <div>
                              <p className="font-gaming text-sm">WAITING FOR RECOGNITION</p>
                              <p className="text-xs text-muted-foreground">
                                VIPs are browsing creators and recognizing good work
                              </p>
                            </div>
                          </>
                        )}
                        {currentCreatorProfile.recognitionStatus === "recognized" && (
                          <>
                            <Bell className="h-8 w-8 text-secondary" />
                            <div>
                              <p className="font-gaming text-sm text-secondary">RECOGNIZED THIS WEEK!</p>
                              <p className="text-xs text-muted-foreground">
                                You've been nominated for an award - claim your NFT badge
                              </p>
                              <div className="flex items-center space-x-1 mt-1">
                                <Hash className="h-3 w-3 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">Ready to mint as NFT</span>
                              </div>
                            </div>
                          </>
                        )}
                        {currentCreatorProfile.recognitionStatus === "claimed" && (
                          <>
                            <CheckCircle className="h-8 w-8 text-primary" />
                            <div>
                              <p className="font-gaming text-sm text-primary">NFT BADGE CLAIMED</p>
                              <p className="text-xs text-muted-foreground">
                                Your recognition NFT has been minted successfully
                              </p>
                              {recognitions.find((r) => r.creatorId === currentCreatorProfile.id && r.tokenId)
                                ?.tokenId && (
                                <div className="flex items-center space-x-1 mt-1">
                                  <Hash className="h-3 w-3 text-primary" />
                                  <span className="text-xs text-primary">
                                    Token #
                                    {
                                      recognitions.find((r) => r.creatorId === currentCreatorProfile.id && r.tokenId)
                                        ?.tokenId
                                    }
                                  </span>
                                </div>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                      <Badge
                        variant={currentCreatorProfile.recognitionStatus === "recognized" ? "default" : "outline"}
                        className="font-gaming text-xs"
                      >
                        {currentCreatorProfile.recognitionStatus.toUpperCase()}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* ... existing cards with enhanced VIP section ... */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-gaming text-primary flex items-center">
                      <Crown className="mr-2 h-5 w-5" />
                      VIP ACCESS
                    </CardTitle>
                    <CardDescription>
                      Get VIP access to recognize and reward outstanding creators with encrypted identity
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!isVIP ? (
                      <div className="space-y-3">
                        <p className="text-sm text-muted-foreground">
                          VIPs can browse creators and give recognition. Your identity stays encrypted for privacy
                          protection.
                        </p>
                        <div className="bg-muted/50 p-3 border border-border text-xs space-y-1">
                          <div className="flex items-center space-x-2">
                            <Shield className="h-3 w-3" />
                            <span>Encrypted VIP ID for privacy</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Calendar className="h-3 w-3" />
                            <span>One nomination per week limit</span>
                          </div>
                        </div>
                        <Button
                          onClick={handleBecomeVIP}
                          disabled={!isWalletConnected}
                          className="bg-secondary text-secondary-foreground hover:bg-secondary/90 font-gaming"
                        >
                          {!isWalletConnected ? "CONNECT WALLET FIRST" : "BECOME VIP (TESTING)"}
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Badge variant="secondary" className="font-gaming">
                          <Star className="mr-1 h-3 w-3" />
                          VIP STATUS ACTIVE
                        </Badge>
                        <p className="text-sm text-muted-foreground">
                          You can now recognize creators. Your identity stays encrypted for privacy.
                        </p>
                        <div className="bg-muted/50 p-2 border border-border text-xs">
                          <div className="flex items-center space-x-2">
                            <Shield className="h-3 w-3" />
                            <span>ID: {currentVIPProfile?.encryptedId?.slice(0, 12)}...</span>
                          </div>
                          <div className="flex items-center space-x-2 mt-1">
                            <Calendar className="h-3 w-3" />
                            <span>
                              Nominations this week: {currentVIPProfile?.hasNominatedThisWeek ? "1/1" : "0/1"}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* ... existing creator registration card ... */}
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-gaming text-primary flex items-center">
                      <UserPlus className="mr-2 h-5 w-5" />
                      CREATOR REGISTRATION
                    </CardTitle>
                    <CardDescription>
                      Register as a creator to receive recognition from VIPs and mint NFT badges
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!isCreator ? (
                      <div className="space-y-3">
                        <p className="text-sm text-muted-foreground">
                          Create your profile so VIPs can find and recognize your great work.
                        </p>
                        <Button
                          onClick={() => setActiveTab("profile")}
                          disabled={!isWalletConnected}
                          className="bg-primary text-primary-foreground hover:bg-primary/90 font-gaming"
                        >
                          {!isWalletConnected ? "CONNECT WALLET FIRST" : "CREATE PROFILE"}
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Badge variant="outline" className="font-gaming">
                          <Trophy className="mr-1 h-3 w-3" />
                          CREATOR REGISTERED
                        </Badge>
                        <p className="text-sm text-muted-foreground">
                          Profile active. VIPs can now recognize your contributions.
                        </p>
                        <div className="bg-muted/50 p-2 border border-border text-xs">
                          <div className="flex items-center space-x-2">
                            <Hash className="h-3 w-3" />
                            <span>Address: {currentCreatorProfile?.address}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* ... existing stats cards ... */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-card border-border">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-2">
                      <Users className="h-8 w-8 text-primary" />
                      <div>
                        <p className="font-gaming text-2xl text-primary">{creators.length}</p>
                        <p className="text-sm text-muted-foreground">REGISTERED CREATORS</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-2">
                      <Award className="h-8 w-8 text-secondary" />
                      <div>
                        <p className="font-gaming text-2xl text-secondary">
                          {creators.reduce((sum, c) => sum + c.recognitions, 0)}
                        </p>
                        <p className="text-sm text-muted-foreground">TOTAL RECOGNITIONS</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-2">
                      <Zap className="h-8 w-8 text-primary" />
                      <div>
                        <p className="font-gaming text-2xl text-primary">
                          {creators.filter((c) => c.isRecognizedThisWeek).length}
                        </p>
                        <p className="text-sm text-muted-foreground">THIS WEEK</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* ... existing creators tab with enhanced VIP info ... */}
          {activeTab === "creators" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="font-gaming text-xl text-primary">CREATOR DIRECTORY</h3>
                {isVIP && (
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary" className="font-gaming text-xs">
                      VIP MODE: CAN RECOGNIZE
                    </Badge>
                    <Badge variant="outline" className="font-gaming text-xs">
                      {currentVIPProfile?.hasNominatedThisWeek ? "NOMINATED THIS WEEK" : "CAN NOMINATE"}
                    </Badge>
                  </div>
                )}
              </div>

              {isVIP && (
                <Card className="bg-secondary/10 border-secondary">
                  <CardContent className="p-4">
                    <p className="text-sm text-muted-foreground">
                      <Crown className="inline h-4 w-4 mr-1" />
                      As a VIP, you can browse creator profiles and recognize outstanding work. Your identity stays
                      encrypted for privacy. You can nominate one creator per week.
                    </p>
                    {currentVIPProfile?.hasNominatedThisWeek && (
                      <p className="text-xs text-muted-foreground mt-2">
                        ⚠️ You have already used your nomination for week {currentWeek}. Come back next week!
                      </p>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* ... existing creator cards with enhanced info ... */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {creators.map((creator) => (
                  <Card key={creator.id} className="bg-card border-border">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarImage src={creator.avatar || "/placeholder.svg"} />
                          <AvatarFallback className="bg-muted">{creator.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="font-gaming text-sm">{creator.name}</CardTitle>
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline" className="text-xs">
                              {creator.recognitions} RECOGNITIONS
                            </Badge>
                            {creator.isRecognizedThisWeek && (
                              <Badge className="bg-primary text-primary-foreground text-xs">WEEK {currentWeek}</Badge>
                            )}
                            {creator.hasPendingBadge && (
                              <Badge className="bg-secondary text-secondary-foreground text-xs">
                                <Gift className="h-3 w-3 mr-1" />
                                NFT
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground mb-2">{creator.bio}</p>
                      <div className="text-xs text-muted-foreground mb-4">
                        <div className="flex items-center space-x-1">
                          <Hash className="h-3 w-3" />
                          <span>{creator.address}</span>
                        </div>
                      </div>
                      {isVIP && (
                        <Button
                          onClick={() => setSelectedCreator(creator)}
                          disabled={currentVIPProfile?.hasNominatedThisWeek || creator.isRecognizedThisWeek}
                          className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90 font-gaming text-xs disabled:opacity-50"
                        >
                          {currentVIPProfile?.hasNominatedThisWeek
                            ? "ALREADY NOMINATED"
                            : creator.isRecognizedThisWeek
                              ? "ALREADY RECOGNIZED"
                              : `RECOGNIZE ${creator.name.toUpperCase()}`}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* ... existing recognition form with enhanced privacy info ... */}
              {selectedCreator && (
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-gaming text-primary">
                      RECOGNIZE {selectedCreator.name.toUpperCase()}
                    </CardTitle>
                    <CardDescription>
                      Give recognition for outstanding work. The creator will be notified but your identity stays
                      encrypted for privacy protection.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-muted/50 p-3 border border-border text-xs space-y-1">
                      <div className="flex items-center space-x-2">
                        <Shield className="h-3 w-3" />
                        <span>Your VIP ID will be encrypted: {currentVIPProfile?.encryptedId?.slice(0, 12)}...</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-3 w-3" />
                        <span>Recognition for week {currentWeek}</span>
                      </div>
                    </div>
                    <Textarea
                      placeholder="Write a reason for recognition (will be encrypted): 'Great educational content this week!'"
                      value={recognitionReason}
                      onChange={(e) => setRecognitionReason(e.target.value)}
                      className="bg-input border-border"
                    />
                    <div className="flex space-x-2">
                      <Button
                        onClick={() => handleRecognizeCreator(selectedCreator)}
                        className="bg-primary text-primary-foreground hover:bg-primary/90 font-gaming"
                      >
                        SUBMIT RECOGNITION
                      </Button>
                      <Button variant="outline" onClick={() => setSelectedCreator(null)} className="font-gaming">
                        CANCEL
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* ... existing profile tab with enhanced form ... */}
          {activeTab === "profile" && (
            <div className="space-y-6">
              {!isCreator ? (
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="font-gaming text-primary">CREATE CREATOR PROFILE</CardTitle>
                    <CardDescription>
                      Register as a creator to receive recognition from VIPs and mint NFT badges. Your profile will be
                      stored on-chain.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Creator Name/Handle</label>
                      <Input
                        placeholder="e.g., CryptoJohn (must be unique)"
                        className="bg-input border-border"
                        value={creatorForm.name}
                        onChange={(e) => setCreatorForm((prev) => ({ ...prev, name: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Bio</label>
                      <Textarea
                        placeholder="Tell VIPs about your work: 'I create educational crypto content and DeFi tutorials'"
                        className="bg-input border-border"
                        value={creatorForm.bio}
                        onChange={(e) => setCreatorForm((prev) => ({ ...prev, bio: e.target.value }))}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Metadata (Optional)</label>
                      <Input
                        placeholder="Additional information about your work"
                        className="bg-input border-border"
                        value={creatorForm.metadata}
                        onChange={(e) => setCreatorForm((prev) => ({ ...prev, metadata: e.target.value }))}
                      />
                    </div>
                    {isWalletConnected && (
                      <div className="bg-muted/50 p-3 border border-border text-xs">
                        <div className="flex items-center space-x-2">
                          <Hash className="h-3 w-3" />
                          <span>Will be registered to: {walletAddress}</span>
                        </div>
                      </div>
                    )}
                    <Button
                      onClick={handleRegisterCreator}
                      disabled={!creatorForm.name || !creatorForm.bio || !isWalletConnected}
                      className="bg-primary text-primary-foreground hover:bg-primary/90 font-gaming"
                    >
                      {!isWalletConnected ? "CONNECT WALLET FIRST" : "REGISTER AS CREATOR"}
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-6">
                  {/* ... existing creator dashboard with enhanced NFT claiming ... */}
                  <Card className="bg-card border-border">
                    <CardHeader>
                      <CardTitle className="font-gaming text-primary">YOUR CREATOR DASHBOARD</CardTitle>
                      <CardDescription>Track your recognitions and claim NFT badges</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="text-center">
                          <p className="font-gaming text-2xl text-primary">
                            {currentCreatorProfile?.recognitions || 0}
                          </p>
                          <p className="text-sm text-muted-foreground">TOTAL RECOGNITIONS</p>
                        </div>
                        <div className="text-center">
                          <p className="font-gaming text-2xl text-secondary">
                            {currentCreatorProfile?.isRecognizedThisWeek ? "1" : "0"}
                          </p>
                          <p className="text-sm text-muted-foreground">THIS WEEK</p>
                        </div>
                        <div className="text-center">
                          <p className="font-gaming text-2xl text-primary">
                            {recognitions.filter((r) => r.creatorId === currentCreatorProfile?.id && r.tokenId).length}
                          </p>
                          <p className="text-sm text-muted-foreground">NFT BADGES OWNED</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* ... enhanced badge claiming section ... */}
                  {currentCreatorProfile?.hasPendingBadge && (
                    <Card className="bg-secondary/10 border-secondary">
                      <CardHeader>
                        <CardTitle className="font-gaming text-secondary flex items-center">
                          <Gift className="mr-2 h-5 w-5" />🏆 CLAIM YOUR RECOGNITION NFT BADGE
                        </CardTitle>
                        <CardDescription>
                          Congratulations! You've been recognized this week. Mint your unique NFT badge to your wallet.
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="bg-card p-4 border border-border">
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <p className="text-sm font-medium">🎖️ Recognition NFT Badge - Week {currentWeek}</p>
                              <p className="text-xs text-muted-foreground">
                                A unique ERC-721 NFT badge showing the week you were recognized
                              </p>
                            </div>
                            <Badge className="bg-secondary text-secondary-foreground">READY TO MINT</Badge>
                          </div>
                          <div className="text-xs text-muted-foreground space-y-1">
                            <p>• Your recognition count will increase on-chain</p>
                            <p>• The NFT metadata includes this week's number</p>
                            <p>• You control when to pay gas fees for minting</p>
                            <p>• VIP identity remains encrypted in the NFT</p>
                          </div>
                        </div>
                        <Button
                          onClick={() => handleMintBadge(currentCreatorProfile.id)}
                          className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90 font-gaming"
                        >
                          <Gift className="mr-2 h-4 w-4" />
                          MINT MY RECOGNITION NFT BADGE
                        </Button>
                      </CardContent>
                    </Card>
                  )}

                  {/* ... existing profile display with enhanced info ... */}
                  <Card className="bg-card border-border">
                    <CardHeader>
                      <CardTitle className="font-gaming text-primary">YOUR PROFILE</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4 mb-4">
                        <Avatar className="h-16 w-16">
                          <AvatarImage src={currentCreatorProfile?.avatar || "/placeholder.svg"} />
                          <AvatarFallback className="bg-muted font-gaming">
                            {currentCreatorProfile?.name.slice(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-gaming text-lg">{currentCreatorProfile?.name}</h3>
                          <p className="text-sm text-muted-foreground">{currentCreatorProfile?.bio}</p>
                        </div>
                      </div>
                      <div className="bg-muted/50 p-3 border border-border text-xs space-y-1">
                        <div className="flex items-center space-x-2">
                          <Hash className="h-3 w-3" />
                          <span>Wallet Address: {currentCreatorProfile?.address}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="h-3 w-3" />
                          <span>Status: {currentCreatorProfile?.isActive ? "Active" : "Inactive"}</span>
                        </div>
                        {currentCreatorProfile?.metadata && (
                          <div className="flex items-center space-x-2">
                            <Star className="h-3 w-3" />
                            <span>Metadata: {currentCreatorProfile.metadata}</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  {recognitions.filter((r) => r.creatorId === currentCreatorProfile?.id && r.tokenId).length > 0 && (
                    <Card className="bg-card border-border">
                      <CardHeader>
                        <CardTitle className="font-gaming text-primary">YOUR NFT BADGE COLLECTION</CardTitle>
                        <CardDescription>Recognition NFT badges you've earned and minted</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {recognitions
                            .filter((r) => r.creatorId === currentCreatorProfile?.id && r.tokenId)
                            .map((recognition) => (
                              <div key={recognition.id} className="bg-muted/50 p-3 border border-border">
                                <div className="flex items-center justify-between mb-2">
                                  <div className="flex items-center space-x-2">
                                    <Trophy className="h-4 w-4 text-primary" />
                                    <span className="font-gaming text-sm">Recognition NFT #{recognition.tokenId}</span>
                                  </div>
                                  <Badge variant="outline" className="text-xs">
                                    Week {recognition.weekNumber}
                                  </Badge>
                                </div>
                                <p className="text-xs text-muted-foreground mb-2">
                                  {atob(recognition.encryptedReason || "")}
                                </p>
                                <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                                  <Shield className="h-3 w-3" />
                                  <span>VIP ID: {recognition.encryptedVIPId?.slice(0, 8)}...</span>
                                </div>
                              </div>
                            ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </div>
          )}

          {activeTab === "recognition" && (
            <div className="space-y-6">
              <div className="text-center space-y-4">
                <h2 className="font-gaming text-3xl text-primary">MY RECOGNITION STATUS</h2>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Check your pending recognitions and mint your NFT badges. Track your weekly recognition progress.
                </p>
              </div>

              {!isCreator ? (
                <Card className="bg-card border-border">
                  <CardContent className="p-8 text-center">
                    <UserPlus className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="font-gaming text-lg text-primary mb-2">CREATOR PROFILE REQUIRED</h3>
                    <p className="text-muted-foreground mb-4">
                      You need to register as a creator to receive recognition and mint NFT badges.
                    </p>
                    <Button
                      onClick={() => setActiveTab("profile")}
                      className="bg-primary text-primary-foreground hover:bg-primary/90 font-gaming"
                    >
                      CREATE PROFILE
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-6">
                  {/* Current Week Recognition Status */}
                  <Card className="bg-card border-border">
                    <CardHeader>
                      <CardTitle className="font-gaming text-primary flex items-center">
                        <Calendar className="mr-2 h-5 w-5" />
                        WEEK {currentWeek} STATUS
                      </CardTitle>
                      <CardDescription>Your recognition status for the current week</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {currentCreatorProfile?.hasPendingBadge ? (
                        <div className="bg-secondary/10 border border-secondary p-4 space-y-4">
                          <div className="flex items-center space-x-3">
                            <Bell className="h-8 w-8 text-secondary animate-bounce" />
                            <div>
                              <p className="font-gaming text-lg text-secondary">🎉 RECOGNITION RECEIVED!</p>
                              <p className="text-sm text-muted-foreground">
                                Congratulations! You've been recognized this week by a VIP member.
                              </p>
                              <div className="flex items-center space-x-2 mt-2">
                                <Shield className="h-4 w-4 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">
                                  VIP identity encrypted for privacy
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-4 border-t border-border">
                            <div>
                              <p className="font-gaming text-sm">READY TO MINT NFT BADGE</p>
                              <p className="text-xs text-muted-foreground">
                                Click below to mint your recognition as an NFT badge (gas fees apply)
                              </p>
                            </div>
                            <Button
                              onClick={() => handleMintBadge(currentCreatorProfile.id)}
                              className="bg-secondary text-secondary-foreground hover:bg-secondary/90 font-gaming"
                            >
                              <Gift className="mr-2 h-4 w-4" />
                              MINT NFT BADGE
                            </Button>
                          </div>
                        </div>
                      ) : currentCreatorProfile?.recognitionStatus === "claimed" ? (
                        <div className="bg-primary/10 border border-primary p-4">
                          <div className="flex items-center space-x-3">
                            <CheckCircle className="h-8 w-8 text-primary" />
                            <div>
                              <p className="font-gaming text-lg text-primary">NFT BADGE MINTED!</p>
                              <p className="text-sm text-muted-foreground">
                                Your recognition NFT has been successfully minted for week {currentWeek}.
                              </p>
                              {recognitions.find((r) => r.creatorId === currentCreatorProfile.id && r.tokenId)
                                ?.tokenId && (
                                <div className="flex items-center space-x-2 mt-2">
                                  <Hash className="h-4 w-4 text-primary" />
                                  <span className="text-sm text-primary font-gaming">
                                    TOKEN #
                                    {
                                      recognitions.find((r) => r.creatorId === currentCreatorProfile.id && r.tokenId)
                                        ?.tokenId
                                    }
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-muted/50 border border-border p-4">
                          <div className="flex items-center space-x-3">
                            <Clock className="h-8 w-8 text-muted-foreground" />
                            <div>
                              <p className="font-gaming text-lg">WAITING FOR RECOGNITION</p>
                              <p className="text-sm text-muted-foreground">
                                Your profile is live! VIPs are browsing creators and recognizing good work.
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">
                                Think of it like waiting to be nominated for an award.
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Recognition History */}
                  <Card className="bg-card border-border">
                    <CardHeader>
                      <CardTitle className="font-gaming text-primary flex items-center">
                        <Trophy className="mr-2 h-5 w-5" />
                        RECOGNITION HISTORY
                      </CardTitle>
                      <CardDescription>Your past recognition NFT badges and achievements</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {recognitions.filter((r) => r.creatorId === currentCreatorProfile?.id).length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {recognitions
                            .filter((r) => r.creatorId === currentCreatorProfile?.id)
                            .map((recognition) => (
                              <div key={recognition.id} className="bg-muted/30 border border-border p-4">
                                <div className="flex items-center justify-between mb-3">
                                  <Badge variant="outline" className="font-gaming text-xs">
                                    WEEK {recognition.weekNumber}
                                  </Badge>
                                  {recognition.tokenId && (
                                    <Badge variant="default" className="font-gaming text-xs">
                                      TOKEN #{recognition.tokenId}
                                    </Badge>
                                  )}
                                </div>

                                <div className="space-y-2">
                                  <p className="font-gaming text-sm text-primary">
                                    RECOGNITION CARD #{recognition.tokenId || "PENDING"}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    Weekly recognition for creator: {currentCreatorProfile?.name}
                                  </p>

                                  {recognition.encryptedReason && (
                                    <div className="bg-background/50 p-2 border border-border">
                                      <p className="text-xs text-muted-foreground mb-1">
                                        Encrypted Recognition Reason:
                                      </p>
                                      <p className="font-mono text-xs text-primary break-all">
                                        {recognition.encryptedReason}
                                      </p>
                                    </div>
                                  )}

                                  <div className="flex items-center space-x-2 pt-2">
                                    <Shield className="h-3 w-3 text-muted-foreground" />
                                    <span className="text-xs text-muted-foreground">VIP identity protected</span>
                                  </div>
                                </div>
                              </div>
                            ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <Award className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                          <p className="font-gaming text-sm text-muted-foreground">NO RECOGNITION HISTORY YET</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Keep creating great content! VIPs will recognize your work.
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Recognition Stats */}
                  <Card className="bg-card border-border">
                    <CardHeader>
                      <CardTitle className="font-gaming text-primary flex items-center">
                        <BarChart3 className="mr-2 h-5 w-5" />
                        RECOGNITION STATS
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="text-center">
                          <p className="font-gaming text-2xl text-primary">
                            {recognitions.filter((r) => r.creatorId === currentCreatorProfile?.id).length}
                          </p>
                          <p className="text-xs text-muted-foreground">TOTAL RECOGNITIONS</p>
                        </div>
                        <div className="text-center">
                          <p className="font-gaming text-2xl text-secondary">
                            {recognitions.filter((r) => r.creatorId === currentCreatorProfile?.id && r.tokenId).length}
                          </p>
                          <p className="text-xs text-muted-foreground">NFT BADGES MINTED</p>
                        </div>
                        <div className="text-center">
                          <p className="font-gaming text-2xl text-primary">{currentWeek}</p>
                          <p className="text-xs text-muted-foreground">CURRENT WEEK</p>
                        </div>
                        <div className="text-center">
                          <p className="font-gaming text-2xl text-muted-foreground">
                            {currentCreatorProfile?.hasPendingBadge ? "1" : "0"}
                          </p>
                          <p className="text-xs text-muted-foreground">PENDING BADGES</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
